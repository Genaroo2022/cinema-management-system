package ar.edu.ort.cines.intefaces;

public interface Puntuable {

	int getPuntos();
	
}
