package ar.edu.ort.cines.intefaces;

import ar.edu.ort.cines.classes.enums.Alimento;

public interface Consumible {

	void consumir(Alimento alimento);
	
}
