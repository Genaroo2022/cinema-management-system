package ar.edu.ort.cines.intefaces;

public interface Identificable<T> {

	T identificate();
	
}
