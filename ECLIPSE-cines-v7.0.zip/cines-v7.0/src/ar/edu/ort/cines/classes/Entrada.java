package ar.edu.ort.cines.classes;

public class Entrada {
	private int fila;
	private int butaca;
	
	
	public Entrada(int fila, int butaca) {
		this.fila = fila;
		this.butaca = butaca;
	}


	public int getFila() {
		return fila;
	}
	public int getButaca() {
		return butaca;
	}
}
