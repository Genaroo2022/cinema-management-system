package ar.edu.ort.cines.classes.enums;

public enum Funcion {
	DIURNA,
	NOCTURNA,
	PRIVADA
}
