package ar.edu.ort.cines.classes.enums;

public enum Estado {
	DISPONIBLE,
	OCUPADO,
	ROTO
}
