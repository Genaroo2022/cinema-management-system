package ar.edu.ort.cines;

import ar.edu.ort.cines.classes.Sala;
import ar.edu.ort.tdas.implementaciones.PilaNodos;

public class PilaDeSala extends PilaNodos<Sala> {

}
